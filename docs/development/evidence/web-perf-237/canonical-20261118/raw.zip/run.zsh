#!/bin/zsh
set -eu
cd "${0:A:h}/vink"
export CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_NET_OFFLINE=true CARGO_BUILD_JOBS=2 RUST_TEST_THREADS=1
export VINK_PG_BIN=/opt/homebrew/opt/postgresql@17/bin PATH="/opt/homebrew/opt/postgresql@17/bin:$PATH"
export VINK_TEST_DATABASE_URL="postgres://postgres:$(<../pgpw)@127.0.0.1:56237/postgres"
export DATABASE_URL="$VINK_TEST_DATABASE_URL"
export VINK_CHROME='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
export npm_config_cache="${PWD:h}/npm-cache"
phase="$1"
shift
case "$phase" in
 web) cmd=(cargo xtask verify web "$@") ;;
 offline) cmd=(node ../offline.mjs offline) ;;
 lab) cmd=(node ../lab.mjs "$@") ;;
 *) cmd=(./tools/local-budget run -- cargo "$@") ;;
esac
date -u
git log -1 --format='head=%H tree=%T'
git status --porcelain
print -r -- "target=$PWD/target command=${cmd[*]}"
exec "${cmd[@]}"
