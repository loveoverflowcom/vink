#!/bin/zsh
set -eu
cd "${0:A:h}"
./run.zsh offline > evidence/fragment-offline.log 2>&1
python3 reclaim.py post-browser
./run.zsh pg test --locked -p vink-app --test postgres conditional_reads:: > evidence/pg-conditional.log 2>&1
./run.zsh pg test --locked -p vink-app --test postgres publication_state:: > evidence/pg-metadata.log 2>&1
./run.zsh corpus test --locked -p vink-app --test document_budget > evidence/provider-corpus.log 2>&1
python3 reclaim.py space
./run.zsh quick xtask verify quick > evidence/quick.log 2>&1
