#!/bin/zsh
set -eu
cd "${0:A:h}"
./run.zsh lib test --locked -p vink-web --features ssr --lib > evidence/final-web-lib.log 2>&1
python3 mutation.py
./run.zsh corpus test --locked -p vink-web --lib public_reads::tests::measure_237_corpus_and_retention_tradeoff -- --ignored --exact --nocapture > evidence/native-final.log 2>&1
./run.zsh web --scenario main --scenario review --scenario auth --scenario return-position --scenario perf-baseline > evidence/web-final.log 2>&1
