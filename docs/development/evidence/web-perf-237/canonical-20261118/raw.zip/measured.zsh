#!/bin/zsh
set -eu
cd "${0:A:h}"
./run.zsh build xtask build web > evidence/build-final-b.log 2>&1
(cd vink && shasum -a 256 target/site/pkg/vink{.js,_bg.wasm}) > evidence/bundle-fixed.sha256
./run.zsh lab fixed > evidence/lab-fixed.log 2>&1
./variants.zsh > evidence/variants.log 2>&1
