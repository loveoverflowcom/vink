import { chromium } from '/private/tmp/vink-editor-preview-tools/node_modules/playwright/index.mjs';
import { spawn, execFileSync } from 'node:child_process';
import { readFileSync, writeFileSync, openSync } from 'node:fs';
import { createHash, randomUUID } from 'node:crypto';
import assert from 'node:assert/strict';
import { setTimeout as delay } from 'node:timers/promises';

const run = process.argv[2];
assert(['base','fixed','unbounded','noop'].includes(run));
const dir = '../evidence';
const base = 'http://127.0.0.1:56238';
const pgBin='/opt/homebrew/opt/postgresql@17/bin';
const db = 'read02_lab';
const pgEnv = {...process.env, PGHOST:process.cwd()+'/../pgsocket', PGPORT:'56237', PGUSER:'postgres'};
const env = {...process.env, DATABASE_URL:process.env.VINK_TEST_DATABASE_URL.replace('://postgres:', '://read02_runtime:').replace('/postgres','/read02_lab'),
  VINK_PROFILE:'local', VINK_BIND:'127.0.0.1:56238', VINK_PUBLIC_ORIGIN:base, VINK_SITE_ROOT:process.cwd()+'/target/site',
  VINK_AUTH_SIGN_IN:'disabled'};
function psql(sql){return execFileSync(pgBin+'/psql',['-XqAt','-v','ON_ERROR_STOP=1','-d',db],{env:pgEnv,input:sql,encoding:'utf8'}).trim();}
let app, browser;
async function stop(){if(app&&app.exitCode===null){const p=new Promise(r=>app.once('exit',r));app.kill('SIGTERM');await p;}app=null;}
async function start(author){const log=openSync(dir+'/app-'+run+'.log','a');app=spawn('target/debug/vink-app',['serve'],{env:{...env,...(author?{VINK_DEV_PRINCIPAL:'11111111-1111-4111-8111-111111111111'}:{})},stdio:['ignore',log,log]});
for(let i=0;i<100;i++){if(app.exitCode!==null)throw Error('app exited '+app.exitCode);if(await fetch(base+'/health/ready').then(r=>r.ok,()=>false))return;await delay(100);}throw Error('app readiness');}
async function request(path,method='GET',body){const r=await fetch(base+'/api/v1'+path,{method,headers:{origin:base,...(body?{'content-type':'application/json'}:{})},body:body?JSON.stringify(body):undefined});const j=await r.json();assert(r.ok,JSON.stringify(j).slice(0,400));return j;}
const sha=s=>createHash('sha256').update(s).digest('hex');
const git=(...a)=>execFileSync('git',a,{encoding:'utf8'}).trim();
const out={sha:git('rev-parse','HEAD'),diff_sha256:sha(git('diff','HEAD')),status:git('status','--porcelain'),profile:'dev, debug=0, incremental=0',run,samples:[],cycles:[],cases:[]};
const save=()=>writeFileSync(dir+'/large-'+run+'.json',JSON.stringify(out,null,2));
try{
  if(run==='base' && !psql("SELECT count(*) FROM works WHERE id IN (SELECT work_id FROM publications)"))throw Error('fixture DB');
  if(!psql("SELECT id FROM revisions WHERE title LIKE 'READ02 RAM %' LIMIT 1")){
    await start(true);
    // These are immutable, synthetic #229/#273 input strings, not prior observations.
    const inputs=JSON.parse(readFileSync('/Users/manhblue/Documents/Codex/2026-11-18/task-5/evidence/budget-browser/fixtures.json','utf8'));
    const poem=inputs.find(x=>x.case==='poem_tabs-200000').document.source;
    const nfd=inputs.find(x=>x.case==='vi_nfd-30000').document.source;
    const sample=JSON.parse(readFileSync('services/vink-app/contracts/http/v1/fixtures/draft.save.request.json')).document.source;
    const startText='Phố cũ mưa giăng sợi mỏng,', endText='đã theo mưa về rất lâu.';
    const max=startText+'\n'.repeat(2097152-Buffer.byteLength(startText+endText))+endText;
    for(const [i,source] of [sample,nfd,poem,poem,poem,poem,poem,max].entries()){
      const title='READ02 RAM '+i;
      const d=await request('/drafts','POST');const saved=await request('/drafts/'+d.work_id,'PUT',{expected_version:d.version??d.draft_version,title,document:{format:'default',source}});
      const s=await request('/works/'+d.work_id+'/snapshots','POST',{command_key:randomUUID(),expected_draft_version:saved.version??saved.draft_version,expected_metadata_version:1});
      assert.match(d.work_id,/^[\da-f-]{36}$/);assert.match(s.revision_id,/^[\da-f-]{36}$/);
      psql("INSERT INTO publications(work_id,revision_id,generation,published_at) VALUES('"+d.work_id+"','"+s.revision_id+"',1,now())");
    }
    await stop();
  }
  await start(false);
  const ids=psql("SELECT work_id FROM revisions WHERE title LIKE 'READ02 RAM %' ORDER BY title").split('\n');
  assert.equal(ids.length,8);
  for(const id of ids){const json=await request('/works/'+id+'/reader');const pub=json.publication??json;const src=pub.document.source;const blocks=src.split(/\r\n|\r|\n/);const pars=[];let lines=[];for(const l of blocks){if(l.trim()){lines.push(l);}else if(lines.length){pars.push(lines.join('\n'));lines=[];}}if(lines.length)pars.push(lines.join('\n'));
    out.cases.push({id,title:pub.title,source_bytes:Buffer.byteLength(src),source_sha256:sha(src),rendered_sha256:sha(pars.join('')),paragraphs:pars.length});}
  assert.equal(out.cases[7].source_bytes,2097152);
  browser=await chromium.launch({executablePath:process.env.VINK_CHROME,headless:true,args:['--disable-gpu']});
  const context=await browser.newContext({viewport:{width:1280,height:900}});
  const page=await context.newPage();const c=await context.newCDPSession(page),bc=await browser.newBrowserCDPSession();
  out.chrome=await bc.send('Browser.getVersion');const attempts=new Map();const errors=[];
  page.on('pageerror',e=>errors.push(String(e)));
  page.on('request',r=>{const p=new URL(r.url()).pathname;if(p.endsWith('/reader'))attempts.set(p,(attempts.get(p)??0)+1);});
  await page.goto(base+'/?q=READ02');await page.locator('.vk-public-row__link').first().waitFor();await page.waitForFunction(()=>document.documentElement.dataset.hydrated==='true');
  const origin=await page.evaluate(()=>performance.timeOrigin);
  async function sample(stage,i){await c.send('HeapProfiler.collectGarbage');const heap=await c.send('Runtime.getHeapUsage');const dom=await c.send('Memory.getDOMCounters');
    const procs=(await bc.send('SystemInfo.getProcessInfo')).processInfo;
    const pidMap=new Map(procs.map(x=>[String(x.id),x.type]));const rss=execFileSync('/bin/ps',['-o','pid=,rss=','-p',[...pidMap.keys()].join(',')],{encoding:'utf8'}).trim().split('\n').map(l=>{const [pid,kib]=l.trim().split(/\s+/);return {pid:+pid,type:pidMap.get(pid),rss_kib:+kib};});
    const wasm=await page.evaluate(async()=>{const mod=await import('/pkg/vink.js');return (await mod.default()).memory.buffer.byteLength;});
    out.samples.push({stage,iteration:i,heap,dom,wasm_bytes:wasm,processes:rss});save();}
  await sample('explore',0);
  const order=[0,1,2,3,4,5,6,7,7,2];for(let i=0;i<50;i++){
    const v=out.cases[order[i%order.length]],path='/api/v1/works/'+v.id+'/reader',before=attempts.get(path)??0;
    const t=performance.now();await page.locator('.vk-public-row__link[href*="'+v.id+'"]').first().click();const body=page.locator('#reader-paper .vk-document');await body.waitFor();
    const seen=await body.evaluate(async b=>({digest:[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(b.textContent)))].map(x=>x.toString(16).padStart(2,'0')).join(''),blocks:b.childElementCount,origin:performance.timeOrigin}));
    assert.equal(seen.digest,v.rendered_sha256);assert.equal(seen.blocks,v.paragraphs);assert.equal(seen.origin,origin);
    const count=(attempts.get(path)??0)-before;if(order[i%order.length]===7 && run!=='unbounded')assert.equal(count,1);
    if(run==='unbounded' && i===8)assert.equal(count,0);
    if(run==='noop')assert.equal(count,1);
    out.cycles.push({iteration:i+1,case:v.title,attempts:count,open_ms:performance.now()-t,full_render:true});
    if([0,2,7,27,47].includes(i))await sample('reader-'+order[i%order.length],i+1);
    await page.locator('#reader-return').click();await page.locator('.vk-public-row__link').first().waitFor();assert.equal(await page.locator('#reader-paper').count(),0);
    if([4,9,19,29,39,49].includes(i))await sample('explore',i+1);
  }
  out.errors=errors;assert.deepEqual(errors,[]);out.indexedDB=await page.evaluate(()=>indexedDB.databases());assert.deepEqual(out.indexedDB,[]);out.result='PASS';save();
}catch(e){out.error=String(e);save();throw e;}finally{await browser?.close();await stop();}
