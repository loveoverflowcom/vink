"""Prune only this run's generated compiler directories after all their consumers exit."""
import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent
work=root/'vink'
target=work/'target'
phase=sys.argv[1]
assert phase in ('post-browser','final','space')
assert subprocess.check_output(['git','branch','--show-current'],cwd=work,text=True).strip()=='codex/read02-canonical-ram-review'
assert target.is_dir() and not target.is_symlink()
args=subprocess.check_output(['ps','-axo','pid=,comm=,args='],text=True)
unsafe=[l[:160] for l in args.splitlines() if ('/cargo ' in l or '/rustc ' in l or '/xtask ' in l or '/vink-app serve' in l or 'node ../lab.mjs' in l or 'node ../offline.mjs' in l or 'node apps/vink-web/e2e/browser-smoke' in l) and not any(x in l for x in ('rg ','sh -','reclaim.py','app-server'))]
assert not unsafe,unsafe
names=['wasm32-unknown-unknown','site'] if phase=='post-browser' else ['debug','release','wasm32-unknown-unknown','site']
preserved=[p for p in target.iterdir() if p.name.startswith('verify-')]
def inventory():
 h=hashlib.sha256();count=0
 for p in sorted(f for d in preserved for f in d.rglob('*') if f.is_file()):
  h.update(str(p.relative_to(target)).encode()+b'\0'+hashlib.file_digest(p.open('rb'),'sha256').digest());count+=1
 return {'files':count,'sha256':h.hexdigest()}
audit={'phase':phase,'before':shutil.disk_usage(root).free,'preserved_qa_before':inventory(),'removed':[]}
for name in names:
 d=target/name
 if not d.is_dir():continue
 assert d.parent==target and not d.is_symlink() and d.resolve()==d
 assert not any(f.name in {'PG_VERSION','pg_wal','outbox','screenshots','evidence'} or f.suffix.lower() in ('.dump','.log','.sql','.sqlite','.db') for f in d.rglob('*'))
 audit['removed'].append([name,subprocess.check_output(['du','-sh',d],text=True).split()[0]])
 shutil.rmtree(d)
audit['after']=shutil.disk_usage(root).free
audit['preserved_qa_after']=inventory()
assert audit['preserved_qa_after']==audit['preserved_qa_before']
(root/'evidence'/('cleanup-'+phase+'.json')).write_text(json.dumps(audit,indent=2))
print(json.dumps(audit))
