from pathlib import Path
import subprocess
root=Path('vink')
f=root/'apps/vink-web/src/freshness.rs'
base=f.read_text()
before='''                self.mark_stale(key);
            }
            self.park_unobserved(key);
'''
assert base.count(before)==1
name='public_reads::tests::joined_resources_disposed_after_delivery_release_the_unmounted_body'
argv=['./run.zsh','mutation','test','--locked','-p','vink-web','--features','ssr','--lib',name,'--','--exact']
try:
 f.write_text(base.replace(before,before.replace('            self.park_unobserved(key);','            // Negative control: omit the completed Resource handoff cleanup.')))
 Path('evidence/handoff-mutant.patch').write_bytes(subprocess.check_output(['git','-C','vink','diff','--','apps/vink-web/src/freshness.rs']))
 with open('evidence/handoff-mutant.log','wb') as log: result=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT)
 assert result.returncode==101 and 'last disposed Resource must release an unmounted oversized reply' in Path('evidence/handoff-mutant.log').read_text(), 'mutation did not fail specifically at the expected ownership assertion'
finally:
 f.write_text(base)
with open('evidence/handoff-restored.log','wb') as log: subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT,check=True)
