#!/bin/zsh
set -eu
cd "${0:A:h}/vink"
export PATH="/opt/homebrew/opt/postgresql@17/bin:$PATH"
export PGHOST="${PWD:h}/pgsocket" PGPORT=56237 PGUSER=postgres
createdb read02_lab
pw=$(<../pgpw)
export VINK_MIGRATE_DATABASE_URL="postgres://postgres:${pw}@127.0.0.1:56237/read02_lab"
target/debug/vink-app migrate
psql -Xq -v ON_ERROR_STOP=1 -d read02_lab <<SQL
CREATE ROLE read02_runtime LOGIN PASSWORD '${pw}';
REVOKE CREATE ON SCHEMA public FROM PUBLIC;
GRANT USAGE ON SCHEMA public TO read02_runtime;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO read02_runtime;
GRANT USAGE ON ALL SEQUENCES IN SCHEMA public TO read02_runtime;
REVOKE INSERT,UPDATE,DELETE ON _sqlx_migrations FROM read02_runtime;
SQL
unset VINK_MIGRATE_DATABASE_URL
export DATABASE_URL="postgres://read02_runtime:${pw}@127.0.0.1:56237/read02_lab" VINK_PROFILE=local
target/debug/vink-app dev-seed
