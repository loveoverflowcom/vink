#!/bin/zsh
set -eu
cd "${0:A:h}/vink"
owned_file=apps/vink-web/src/public_reads.rs
git diff --exit-code HEAD -- "$owned_file" >/dev/null
base_sha=$(git rev-parse HEAD)
recover(){
    if [[ -n "${active_patch:-}" ]]; then git apply -R --check "$active_patch" && git apply -R "$active_patch"; fi
}
trap recover EXIT
for policy in unbounded noop; do
    [[ "$(git rev-parse HEAD)" == "$base_sha" ]]
    python3 - "$policy" "$owned_file" <<'PY'
import sys
from pathlib import Path
p=Path(sys.argv[2]);s=p.read_text()
if sys.argv[1]=='unbounded':
 old='max_total_bytes: Some(2 * 1024 * 1024),\n        max_entry_bytes: Some(1024 * 1024),'
 new='max_total_bytes: None,\n        max_entry_bytes: None,'
 assert s.count(old)==1;s=s.replace(old,new)
else:
 for old,new in [('        coord: Coordinator,','        coord: Coordinator<crate::read_cache::NoOpCache>,'),('            coord: Coordinator::new(Policy::V1),','            coord: Coordinator::with_cache(Policy::V1, crate::read_cache::NoOpCache),')]:
  assert s.count(old)==1;s=s.replace(old,new)
p.write_text(s)
PY
    git diff HEAD -- "$owned_file" > "../evidence/${policy}.patch"
    active_patch="../evidence/${policy}.patch"
    ../run.zsh variant xtask build web > "../evidence/build-${policy}.log" 2>&1
    shasum -a 256 target/site/pkg/vink{.js,_bg.wasm} > "../evidence/bundle-${policy}.sha256"
    ../run.zsh lab "$policy" > "../evidence/lab-${policy}.log" 2>&1
    recover
    active_patch=''
done
git diff --exit-code HEAD -- "$owned_file"
