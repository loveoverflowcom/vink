# Vink logo — final selected pack

This folder gathers the selected Vink logo assets that are available in this chat session.

Included:
- SVG: light, dark, compact, and mono variants.
- PNG: light and dark exports at 24, 32, 48, 96, 192, 512 px.
- Preview board: `vink-final-review-board.png`
- Theme preview: `vink-logo-v4-preview.png`, `preview.svg`, `preview.html`

Note:
- The user approved the latest rounded direction and asked to keep PNG + SVG.
- The GitHub connector is not available in this chat, so `issue_update.md` contains a ready-to-paste update for the GitHub issue.
