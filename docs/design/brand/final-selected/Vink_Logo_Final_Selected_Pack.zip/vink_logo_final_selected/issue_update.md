## Chốt hướng logo Vink

Đã chốt hướng hiện tại:
- Vòng tròn tròn trịa hơn, gần hướng của ảnh review số 1.
- Thân bút dày hơn, ăn vào vòng hơn và khoảng trống được siết lại.
- Đầu ngòi giữ dạng hình thoi, trục ngòi chếch nhẹ thay vì dựng thẳng.
- Giữ bộ màu lavender/purple, có đủ biến thể Light và Dark.

### Bộ tài sản kèm theo
- SVG: light / dark / compact / mono
- PNG: light và dark ở 24, 32, 48, 96, 192, 512 px
- Preview board và preview light/dark

### Ghi chú phạm vi
- Đây là hướng đã được người dùng chốt trong review hiện tại.
- Chưa tự merge vào production và chưa tự deploy.
- Khi tích hợp vào app cần tiếp tục kiểm tra header, rail, mobile, favicon và app icon.
