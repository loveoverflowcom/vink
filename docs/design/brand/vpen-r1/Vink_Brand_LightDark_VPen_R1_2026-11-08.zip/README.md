# Vink — Light / Dark logo system · preview revision 01

This asset pack is a proposed redesign based on the **user-approved raster reference**, not a commit to the repository. The logo consists of a stylized V/fountain-pen symbol, three ink/page strokes, an outlined `Vink` wordmark, and an ink droplet over the i. **It is not the circular mark currently shipped in `develop`.**

## Source and geometry

- Reference: user-approved 1254×1254 PNG from this conversation. Its background was removed through saturation segmentation and the silhouette traced into real SVG paths (no bitmap embedded in SVG).
- Outlines of icon and letters are paths; there is no external font dependency. Smooth gradient fills are native SVG.
- The shadow-like violet overlay of the main pen shape was redrawn as an editable gradient layer clipped to the traced original outline. This is a visual refinement, not a pixel-identical reproduction of every interior shade from the source PNG.
- No border, glow, raster background, CSS filter, or drop shadow baked into artwork.
- Centered symbol is intentionally **not circular**. No ring is added; this is the V/pen design selected by the user.

## Files

- `svg/vink-lockup-light.svg` / `svg/vink-lockup-dark.svg`: full horizontal signature. ViewBox (126 414 1018 410); aspect ratio 2.48.
- `svg/vink-mark-light.svg` / `svg/vink-mark-dark.svg`: symbol only, square viewBox (120 414 410 410), preserveAspectRatio.
- `svg/vink-lockup-mono.svg` / `svg/vink-mark-mono.svg`: single-color `currentColor`, fallback for forced-colors and other monochrome uses (inline SVG, or use an external SVG as a CSS mask for currentColor).
- `png/vink-mark-{light,dark}-{24,32,48,96,192,512,1024}.png`: transparency-preserving ready-to-use PNG sizes for web or native image resources.
- `cmp/drawable/vink_mark_{light,dark}_{96,512}.png` and `vink_lockup_{light,dark}.png`: resource-name-compatible PNGs for Compose Multiplatform; choose the 96 version for a small UI logo.
- `png/vink-lockup-{light,dark}-{640w,1280w}.png`: transparent wordmark PNG fallback.
- `preview/vink-light-dark-review.png`: actual SVG renders on realistic light/dark UI surfaces.
- `integration/vink-logo-example.html` and `integration/vink-logo.css`: responsive light/dark usage example for a UI whose root has `data-theme=light|dark` or follows OS by default.
- `asset-manifest.json`: SHA-256 digests of generated files for review and import.

## Palette design

| Element | Light | Dark |
|---|---|---|
| Main V top | #EF5F8B → #D62E93 | #FF9EBC → #F37EB1 |
| Purple ink end | #552184 | #AA8EF5 |
| Wordmark left | #DF347E | #FFA3BE |
| Wordmark right | #562189 | #B89AFE |
| Example surface (preview only) | #FFFFFF | #181321 |

The backgrounds are **not part of logo exports**; do not hardcode the example background colors over Vink's semantic M3 tokens. Review visual contrast at 24px and in both themes before merging.

## Vink repository integration checklist

1. Keep the existing `apps/vink-web/assets/brand` intact until the preview is approved.
2. Replace the asset family together; the current `favicon.svg`, manifest icons, PNG derivatives and theme asset URLs reference the existing circular mark. Do not replace a single SVG while leaving inconsistent icons behind.
3. For the Explore header currently using an SVG + Literata text, use **mark only** plus existing text, *or* use the full lockup in place of both. Never render the two words `Vink` twice.
4. Update generated APK/iOS resources only after verifying the mark-only transparent exports and OS masking/safe area requirements. Square logo ≠ launcher icon maskable by default.
5. Update `provenance.json`, hashes, manifests, preloads, tests and docs according to the repo's brand pipeline; preserve the original selected pack as historical reference.
6. Test SSR first paint, explicit Light/Dark, System theme, high DPI, reduced motion, 200% text, forced-colors and actual Web/CMP runtime.

**Status:** ready-to-import candidate assets for code review, **not yet user-approved in production**, and not yet pushed to GitHub.

SVG shape outlines were vector-traced from a high-resolution rendered reference (not recovered original Bézier source). The pack is editable and resolution-independent, but a designer may still wish to refine a handful of corner anchors before formal brand lock.

